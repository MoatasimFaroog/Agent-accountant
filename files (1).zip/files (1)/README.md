# AI Bookkeeper Agent for Odoo Integration

This project implements an AI-powered agent to automate bookkeeping tasks in Odoo, focusing on Accounting and Invoicing modules. The agent uses Odoo Web Services (XML-RPC) for integration.

## Features

1. **Data Ingestion & OCR**: Extracts data from invoice attachments using OCR and auto-fills Vendor Bills in Odoo.

2. **Automated Reconciliation**: Fetches bank statements and matches them with journal entries, populating the reconciliation widget and flagging discrepancies.

3. **AR/AP Automation**: Monitors invoice statuses, sends follow-up emails for overdue AR, and schedules AP payments.

4. **Payroll & Reporting**: Syncs with payroll for journal entries and generates real-time P&L and Balance Sheet reports.

5. **System Guardrails**: Implements confidence scoring; if AI confidence < 90%, sets records to Draft for human review. No manual edits to posted entries without audit logs.

## Technical Stack

- Python 3.8+
- Odoo XML-RPC API
- OCR: EasyOCR or Tesseract
- AI Categorization: Placeholder (can integrate OpenAI or custom ML model)
- Libraries: xmlrpc.client, easyocr, pandas, etc.

## Setup

1. Clone the repository.
2. Install dependencies: `pip install -r requirements.txt`
3. Configure Odoo connection in `config.py`.
4. Run the agent: `python main.py`

## Odoo Configuration

- Ensure the Odoo instance has the Accounting and Invoicing modules installed.
- Add a custom field 'confidence_score' to relevant models (e.g., account.move) via Odoo Studio or custom module.
- Set up email templates for AR follow-ups.

## Deployment

### Local Deployment

Follow the setup steps above. Run manually or via cron jobs.

### Docker Deployment

1. Build the image: `docker build -t ai-bookkeeper .`
2. Run the container: `docker run -e ODOO_URL=http://your-odoo -e ODOO_DB=yourdb ai-bookkeeper`

### Cloud Deployment (e.g., AWS, Heroku)

- Use Docker for containerization.
- Schedule with cron or cloud schedulers (e.g., AWS Lambda, Cloud Run).
- Store secrets in environment variables or secret managers.

## Usage

- Run scheduled tasks via cron or manually execute modules.
- Monitor logs for discrepancies and low-confidence records.

## Note

This is an external agent; for full integration, consider developing custom Odoo modules for internal hooks.