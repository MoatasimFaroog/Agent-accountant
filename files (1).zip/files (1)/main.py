from odoo_client import OdooClient
from ocr_processor import OCRProcessor
from reconciliation import ReconciliationAgent
from ar_ap_automation import ARAPAgent
from payroll_reporting import PayrollAgent
from ai_guardrails import AIGuardrails

def main():
    client = OdooClient()
    ocr = OCRProcessor()
    recon = ReconciliationAgent(client)
    arap = ARAPAgent(client)
    payroll = PayrollAgent(client)
    ai = AIGuardrails()

    # Example: OCR on an attachment
    # Assume attachment bytes from Odoo
    # text = ocr.extract_text(attachment_bytes)
    # data = ocr.extract_invoice_data(text)
    # bill_id = client.create('account.move', [{'move_type': 'in_invoice', ...}])
    # ai.check_and_set('account.move', bill_id, data)

    # Run automations
    recon.run()
    arap.run()
    payroll.run()

if __name__ == "__main__":
    main()