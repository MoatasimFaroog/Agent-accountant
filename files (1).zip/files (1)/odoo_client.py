import xmlrpc.client
from config import ODOO_URL, ODOO_DB, ODOO_USERNAME, ODOO_PASSWORD

class OdooClient:
    def __init__(self):
        self.url = ODOO_URL
        self.db = ODOO_DB
        self.username = ODOO_USERNAME
        self.password = ODOO_PASSWORD
        self.common = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/common')
        self.models = xmlrpc.client.ServerProxy(f'{self.url}/xmlrpc/2/object')
        self.uid = self.authenticate()

    def authenticate(self):
        uid = self.common.authenticate(self.db, self.username, self.password, {})
        if not uid:
            raise Exception("Authentication failed: Please check your credentials or database name.")
        return uid

    def execute(self, model, method, *args):
        try:
            return self.models.execute_kw(self.db, self.uid, self.password, model, method, *args)
        except xmlrpc.client.Fault as fault:
            raise Exception(f"XML-RPC Fault occurred: {fault.faultString} (Code: {fault.faultCode})")
        except Exception as e:
            raise Exception(f"An error occurred during execution: {e}")

    def clean_domain(self, domain):
        # Verify if domain is valid and remove invalid items
        if not isinstance(domain, list):
            raise ValueError("Domain must be a list of conditions.")
        # Remove invalid items (e.g., False)
        return [cond for cond in domain if cond]

    def search_read(self, model, domain, fields=None):
        # Clean domain to ensure it doesn't have invalid or malformed items
        try:
            domain = self.clean_domain(domain)
            return self.execute(model, 'search_read', domain, {'fields': fields or []})
        except Exception as e:
            raise Exception(f"Error in search_read with model {model}: {e}")

    def create(self, model, data):
        return self.execute(model, 'create', data)

    def write(self, model, ids, data):
        return self.execute(model, 'write', ids, data)

    def unlink(self, model, ids):
        return self.execute(model, 'unlink', ids)