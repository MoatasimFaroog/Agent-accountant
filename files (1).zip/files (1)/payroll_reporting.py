from odoo_client import OdooClient

class PayrollAgent:
    def __init__(self, client):
        self.client = client

    def sync_payroll_entries(self):
        # Fetch payslips and create journal entries
        payslips = self.client.search_read('hr.payslip', [['state', '=', 'done']], ['id', 'employee_id', 'net'])
        for slip in payslips:
            # Create account.move for payroll
            move_data = {
                'move_type': 'entry',
                'journal_id': 1,  # Assume journal ID
                'line_ids': [
                    (0, 0, {'account_id': 1, 'debit': slip['net'], 'name': f'Payroll for {slip["employee_id"][1]}'}),
                    (0, 0, {'account_id': 2, 'credit': slip['net'], 'name': 'Payroll Expense'})
                ]
            }
            self.client.create('account.move', [move_data])

    def generate_reports(self):
        # Fetch P&L and Balance Sheet data
        # Use account.financial.report or custom query
        pl_data = self.client.execute('account.financial.report', 'get_lines', [1], {'date_from': '2024-01-01', 'date_to': '2024-12-31'})  # Simplified
        print("P&L Report:", pl_data)
        # Similarly for Balance Sheet

    def run(self):
        self.sync_payroll_entries()
        self.generate_reports()