from odoo_client import OdooClient
from datetime import datetime, timedelta
import smtplib  # Or use Odoo's email system

class ARAPAgent:
    def __init__(self, client):
        self.client = client

    def monitor_ar(self):
        # Fetch overdue out_invoices
        overdue = self.client.search_read('account.move', [
            ['move_type', '=', 'out_invoice'],
            ['payment_state', '=', 'not_paid'],
            ['invoice_date_due', '<', datetime.now().date().isoformat()]
        ], ['id', 'partner_id', 'amount_total'])
        for inv in overdue:
            self.send_followup_email(inv)

    def send_followup_email(self, invoice):
        # Use Odoo's mail.thread to send email
        message = f"Reminder: Invoice {invoice['id']} is overdue. Amount: {invoice['amount_total']}"
        self.client.execute('mail.thread', 'message_post', [invoice['partner_id'][0]], {
            'body': message,
            'message_type': 'email',
            'partner_ids': [invoice['partner_id'][0]]
        })

    def schedule_ap_payments(self):
        # Fetch in_invoices due soon
        due_soon = self.client.search_read('account.move', [
            ['move_type', '=', 'in_invoice'],
            ['payment_state', '=', 'not_paid'],
            ['invoice_date_due', '<=', (datetime.now() + timedelta(days=7)).date().isoformat()]
        ], ['id', 'date_due'])
        # Schedule payments (simplified: mark for payment)
        for inv in due_soon:
            print(f"Schedule payment for invoice {inv['id']} due {inv['date_due']}")

    def run(self):
        self.monitor_ar()
        self.schedule_ap_payments()