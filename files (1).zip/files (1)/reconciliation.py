from odoo_client import OdooClient
import pandas as pd

class ReconciliationAgent:
    def __init__(self, client):
        self.client = client

    def fetch_bank_statements(self):
        # Fetch bank statement lines
        lines = self.client.search_read('account.bank.statement.line', [], ['id', 'date', 'amount', 'ref'])
        return pd.DataFrame(lines)

    def fetch_move_lines(self):
        # Fetch unreconciled move lines
             domain = [['reconciled', '=', False]]
             print(f"Domain being sent to Odoo: {domain}")
        lines = self.client.search_read('account.move.line', domain, [['reconciled', '=', False]], ['id', 'date', 'debit', 'credit', 'ref'])
        return pd.DataFrame(lines)

    def auto_match(self, statements, moves):
        # Simple matching logic: match by amount and ref
        matches = []
        for _, stmt in statements.iterrows():
            potential = moves[(moves['debit'] == stmt['amount'] or moves['credit'] == stmt['amount']) & (moves['ref'] == stmt['ref'])]
            if not potential.empty:
                match = potential.iloc[0]
                matches.append((stmt['id'], match['id']))
                moves = moves.drop(match.name)  # Remove matched
        return matches

    def reconcile(self, matches):
        for stmt_id, move_id in matches:
            # Use Odoo's reconciliation logic; this is simplified
            self.client.write('account.move.line', [move_id], {'reconciled': True})
            # Populate reconciliation widget (this might require custom logic)

    def flag_discrepancies(self, unmatched_statements, unmatched_moves):
        # Log or create discrepancy records
        for _, stmt in unmatched_statements.iterrows():
            print(f"Discrepancy: Unmatched bank statement {stmt['id']}")
        # Similarly for moves
        # For custom dashboard, perhaps create records in a custom model if available

    def run(self):
        statements = self.fetch_bank_statements()
        moves = self.fetch_move_lines()
        matches = self.auto_match(statements, moves)
        self.reconcile(matches)
        # Flag unmatched
        unmatched_stmts = statements[~statements['id'].isin([m[0] for m in matches])]
        unmatched_moves = moves[~moves['id'].isin([m[1] for m in matches])]
        self.flag_discrepancies(unmatched_stmts, unmatched_moves)