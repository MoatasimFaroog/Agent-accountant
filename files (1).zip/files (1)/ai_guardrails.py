import openai
from config import OPENAI_API_KEY, CONFIDENCE_THRESHOLD

class AIGuardrails:
    def __init__(self):
        openai.api_key = OPENAI_API_KEY

    def categorize_and_score(self, data):
        # Use AI to categorize expense/income
        prompt = f"Categorize this transaction: {data}. Provide category and confidence score (0-1)."
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=100
        )
        result = response.choices[0].text.strip()
        # Parse category and score
        # Simplified parsing
        category = result.split(',')[0]
        score = float(result.split(',')[1]) if len(result.split(',')) > 1 else 0.5
        return category, score

    def check_and_set(self, model, record_id, data):
        category, score = self.categorize_and_score(data)
        if score < CONFIDENCE_THRESHOLD:
            # Set to draft
            self.client.write(model, [record_id], {'state': 'draft', 'confidence_score': score})
        else:
            self.client.write(model, [record_id], {'confidence_score': score})
        return category