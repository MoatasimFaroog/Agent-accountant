import easyocr
from PIL import Image
import io
import re
from config import OCR_ENGINE

class OCRProcessor:
    def __init__(self):
        if OCR_ENGINE == 'easyocr':
            self.reader = easyocr.Reader(['en'])  # Add languages as needed
        else:
            raise ValueError("Only easyocr is supported")

    def extract_text(self, image_bytes):
        if OCR_ENGINE == 'easyocr':
            image = Image.open(io.BytesIO(image_bytes))
            results = self.reader.readtext(image)
            text = ' '.join([res[1] for res in results])
        else:
            raise ValueError("Unsupported OCR engine")
        return text

    def extract_invoice_data(self, text):
        # Simple regex-based extraction; enhance with AI for better accuracy
        data = {}
        match = re.search(r'Invoice\s*#?\s*([A-Z0-9]+)', text, re.I)
        data['invoice_number'] = match.group(1) if match else None
        match = re.search(r'(\d{1,2}/\d{1,2}/\d{4})', text)
        data['date'] = match.group(1) if match else None
        match = re.search(r'Total\s*[:$]*\s*(\d+\.\d{2})', text, re.I)
        data['total'] = float(match.group(1)) if match else None
        # Add more fields as needed
        return data